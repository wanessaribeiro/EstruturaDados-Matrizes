import java.util.Random;

public class Matriz {

	public static void main(String[] args) {
		
		int[][] matriz = new int [10][10];
		int[][] matrizc = new int [10][10];
		int[][] matrizr= new int [10][10];
		int r = 0;
		Random rd = new Random ();
		
		System.out.println("MATRIZ PREENCHIDA COM NUMEROS ALEATORIOS:");
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				matriz[i][j] = rd.nextInt(3);
				matrizc[i][j] = rd.nextInt(3);
				System.out.print(" " + matriz[i][j] + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------------");
		System.out.println();
		System.out.println("TRIANGULO SUPERIOR:");
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(i < j)System.out.print("[" + matriz[i][j] + "]");
				else System.out.print(" " + matriz[i][j] + " ");
			}
			
			System.out.println();
		}
	
		
		System.out.println("---------------------------");
		System.out.println();
		System.out.println("TRIANGULO INFERIOR:");
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(i > j)System.out.print("[" + matriz[i][j] + "]");
				else System.out.print(" " + matriz[i][j] + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------------");
		System.out.println();
		System.out.println("DIAGONAL PRINCIPAL:");
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(i == j)System.out.print("[" + matriz[i][j] + "]");
				else System.out.print(" " + matriz[i][j] + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------------");
		System.out.println();
		System.out.println("DIAGONAL SECUNDARIA:");
		System.out.println();
		
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
				if(i + j == 9)System.out.print("[" + matriz[i][j] + "]");
				else System.out.print(" " + matriz[i][j] + " ");
			}
			
			System.out.println();
		}
		
		System.out.println("---------------------------");
		System.out.println();
		System.out.println("MATRIZ MULTIPLICADA POR ELA MESMA:");
		System.out.println();
		
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matrizc[0].length; j++) {
				for (int k = 0; k < matriz[0].length; k++) {
					r = matriz[i][k] * matriz[k][j] + r;
				}
				matrizr[i][j] = r;
				r = 0;
				System.out.print(" " + matrizr[i][j] + " ");
			}
			
			
			
			System.out.println();
		}
		
		
	}

}
